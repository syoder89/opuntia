#!/bin/bash

ip=$1
type=$2
mac=$3

[ -z $ip ] && echo "Must specify IP" && exit 1
[ -z $type ] && echo "Must specify type: ap or sta" && exit 1
[ -z $mac ] && echo "Must specify MAC address" && exit 1

rm -f /root/.ssh/known_hosts
sed -ie "s/option macaddr.*/option macaddr '$mac'/" ${type}-cfg/etc/config/network
cd ${type}-cfg; tar czf ../${type}-cfg.tar.gz  *; cd ..
scp ${type}-cfg.tar.gz $ip:/tmp && ssh -y $ip "sysupgrade -r /tmp/${type}-cfg.tar.gz && reboot"
