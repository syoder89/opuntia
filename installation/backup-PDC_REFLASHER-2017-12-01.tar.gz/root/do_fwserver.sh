#!/bin/bash
. /usr/share/libubox/jshn.sh

cd /root
MACFILE=S020000.MAC
IMG="opuntia-AP3350-4.8.7-r33978-factory.img"
#IMG="opuntia-AP3500-4.8.3-r27248-factory.img"

# Wait for rssileds to start (S96 for some dumb reason!)
sleep 5
/etc/init.d/rssileds stop

yellow_led="/sys/class/leds/wpj344:yellow:sig2"
red_led="/sys/class/leds/wpj344:red:sig1"
green_led="/sys/class/leds/wpj344:green:sig3"

led_on() {
	led="$1"
        echo timer > $led/trigger
        echo 255 > $led/brightness
}

led_off() {
	led="$1"
        echo none > $led/trigger
        echo 0 > $led/brightness
}

get_token() {
	json=$(curl -skL http://$ip/cgi-bin/luci/rpc/auth -X POST -d '{ "method": "login", "params": ["root", "imagestream"], "id": 1}')
	eval $( jshn -r "$json" 2>/dev/null)
	[ "$?" != "0" ] && return 1
	json_get_var result result
	echo $result
	return 0
}

# Firmware Version: 4.8.7 r33976
# Loader Version: U-Boot 1.1.4-gf04cd084-dirty (Jan 5 2017 - 15:02:07)
# Radio MAC address: 04:f0:21:38:e9:5b
# Ethernet MAC address: 04:f0:21:38:e9:58
# Company Name: ImageStream Internet Solutions
# Model Name: AP3350
# Flash Size: 16 MB
# RAM Size: 128 MB
# PCIe Radio Detected: 802.11nac Qualcomm Atheros QCA9880

check_install() {
	cd /root
	echo -n "Uploaded firmware. Waiting for flash process $new_mac..."
	ip=""
	ip neigh flush dev br-Clients
	while : ; do ip=$(grep br-Clients /proc/net/arp | grep ${new_mac} | awk '{ print $1}' | grep -v '192.168.1.1$'); [ "$ip" != "" ] && break; sleep 10; echo -n "."; done
	echo
	led_off $red_led
	echo "AP is booting at IP $ip..."
#	while : ; do
#		token=$(get_token)
#		[ "$token" != "" ] && break
#	done

	echo -n "Waiting for AP to fully boot..."
	while : ; do
#        	json=$(curl -skL http://$ip/cgi-bin/luci/rpc/sys?auth=$token -X POST -d '{ "method": "syslog", "id": 1}')
#        	eval $( jshn -r "$json" 2>/dev/null)
#		[ "$?" != "0" ] && token=$(get_token)
#        	json_get_var result result
#        	echo "$result" | grep "init complete" > /dev/null && break
		data=$(curl -skL https://root:imagestream@$ip/prod_info.txt)
		echo "$data" | grep "Model Name: AP3350" > /dev/null && {
			new_mac=$(echo "$data" | grep "Ethernet MAC" | awk '{ print $4 }')
			radio_mac=$(echo "$data" | grep "Radio MAC" | awk '{ print $4 }')
			if [ -f is_sta ]; then
				type="STA"
				rm -f is_sta
			else
				type="AP"
				touch is_sta
			fi
			echo "$data"
			echo "$data" > install_logs/${new_mac}.log
			echo "$mac	$new_mac	$radio_mac	$type" >> all.log
			mv macs_avail/$MACFILE macs_used/
			break
		}
        	sleep 10
		echo -n "."
	done
	echo
	echo "******************************************************************************"
	echo "AP is fully booted with the ImageStream firmware. It is safe to power off now."
	echo "******************************************************************************"
	echo
	echo "Now run:"
	echo "./do_cfg.sh $ip ${type,,} ${new_mac^^}"
	echo
}

led_off $red_led
led_off $green_led
led_off $yellow_led

[ ! -f /tmp/${IMG} ] && wget http://router-updates.imagestream.com/opuntia/4.8/${IMG} -O /tmp/${IMG}
while : ; do
	led_on $green_led
	echo "Waiting for AP at 192.168.1.1..."
	while : ; do
		arping 192.168.1.1 -I br-Clients -c 3 > /dev/null && break
	done
	led_off $green_led
	led_on $green_led
	led_on $yellow_led
	led_on $red_led
	while : ; do
		set -x
		mac=$(grep '192.168.1.1 ' /proc/net/arp | awk '{print $4}')
		set +x
		[ "$mac" != "" ] && break
		echo "Failed to get MAC address, trying to ping..."
		ping -c 1 192.168.1.1 > /dev/null 2>&1
	done
	echo "Found it MAC $mac, now flashing firmware..."
	cd macs_avail
	MACFILE="$(ls -1 | head -n 1)"
	tftp-hpa -v -m binary 192.168.1.1 -c put ${MACFILE}  || exit 1
	sleep 3
	new_mac="b0:91:37:${MACFILE:1:2}:${MACFILE:3:2}:${MACFILE:5:2}"
	# Convert to lowercase
	new_mac="${new_mac,,}"
	cd /tmp
	tftp-hpa -v -m binary 192.168.1.1 -c put ${IMG} && check_install
	led_off $yellow_led
	sleep 10
done
